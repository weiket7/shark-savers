<?php

class Test extends Eloquent {

	protected $table = 'test';

}
