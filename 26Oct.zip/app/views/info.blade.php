@section('content')
<br>

Slider<br>
870px width x 483px height
<br><br>

One image in 3 column grid<br>
722px width x any height
<br><br>

Ambassador image<br>
520px width x 482px height
<br><br>

Supporter banner – 872px width
<br><br>

Supporter logo – 300px width<br>
  In grid it’s resized to 100x100
<br><br>

@stop